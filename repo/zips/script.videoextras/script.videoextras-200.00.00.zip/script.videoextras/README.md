![VideoExtras](icon.png)

VideoExtras is an addon that allows you to list and view your DVD or Bluray extras via Kodi. Built on top of work done by Robwebset and malvinas2, this fork adds Python 3 and Kodi Nexus support to VideoExtras.


For more details on how to use VideoExtras please refer to the wiki:

[Add-on:VideoExtras](https://github.com/AMoo-Miki/script.videoextras/wiki)
