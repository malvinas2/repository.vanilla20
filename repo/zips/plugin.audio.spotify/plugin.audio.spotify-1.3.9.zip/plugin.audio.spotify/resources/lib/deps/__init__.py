import os
import sys

sys.path.insert(1, os.path.join(os.path.dirname(__file__)))
