# plugin.audio.spotify
Unofficial spotify plugin for Kodi, (for now) not yet available in the official Kodi repo.

Uses 'bottle' and 'librespot - spotty' for playback, and 'spotipy' for the playlist, albums, etc. menus.

Thanks to mherger for creating the special ['spotty'](https://github.com/michaelherger/librespot) branch forked off librespot.

This a fork of the [marcelveldt](https://github.com/marcelveldt) version, modified to work with Kodi 19 and 20.
Thanks to Ldsz, Elkropac, and FernetMenta for getting it to work with Python 3.9+.

## Support
Create issue in Github.
